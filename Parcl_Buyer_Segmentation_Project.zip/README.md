# Machine Learning–Based Buyer Segmentation and Investment Profiling for Real Estate Market Intelligence

**Parcl Co. Limited × Unified Mentor**

## What's in this package

```
project/
├── 01_clean_and_engineer.py     # Step 1-2: data cleaning + feature engineering
├── 02_clustering.py             # Step 3-6: scaling, K-Means + Hierarchical clustering, evaluation, labeling
├── 03_eda_extra.py              # Additional EDA visuals for the report
├── build_report.js              # Generates the Word research report
├── data/
│   ├── client_features.csv      # Cleaned, merged, engineered client-level dataset
│   └── clients_clustered.csv    # Final dataset with cluster/segment labels
├── outputs/
│   ├── Buyer_Segmentation_Research_Report.docx   # Full research paper
│   ├── cluster_profile.csv                       # Segment-level summary stats
│   ├── clustering_summary.txt                    # Model metrics
│   └── *.png                                     # All charts used in the report
└── app/
    └── app.py                   # Streamlit dashboard (run: streamlit run app.py)
```

## How to run the dashboard

```bash
cd app
pip install streamlit plotly pandas numpy
streamlit run app.py
```

The dashboard has four modules — Segmentation Overview, Investor Behavior, Geographic Analysis,
and Segment Insights — with sidebar filters for country, region, acquisition purpose, client type,
and segment.

## How to reproduce the analysis

```bash
python3 01_clean_and_engineer.py   # -> data/client_features.csv
python3 02_clustering.py           # -> data/clients_clustered.csv, outputs/*.png
python3 03_eda_extra.py            # -> additional outputs/*.png
node build_report.js               # -> outputs/Buyer_Segmentation_Research_Report.docx
```

## Headline result

Four buyer segments were identified via K-Means (k=4), validated against Ward-linkage
Hierarchical clustering:

| Segment | Clients | Avg Total Investment | Defining trait |
|---|---|---|---|
| High-Net-Worth Investors | 81 (4.1%) | $2.14M | Oldest, deepest portfolios, rarely finance |
| Premium / Global Investors | 664 (33.2%) | $1.48M | Priciest, largest units per deal |
| Mainstream Buyers | 907 (45.4%) | $1.09M | Largest group, lowest satisfaction |
| First-Time Buyers | 348 (17.4%) | $1.09M | Youngest, most loan-dependent, single rapid-purchase window |

**Key finding:** demographic fields (client type, country) barely differ across segments —
the real drivers are deal size, financing behavior, and buying tenure. Full detail in the
research report.
